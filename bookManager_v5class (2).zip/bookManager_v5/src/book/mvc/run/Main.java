package book.mvc.run;

import book.mvc.view.BookMenu;

public class Main {

	public static void main(String[] args) {
		// bookManager start
		new BookMenu().displayMenu();
	}

}
